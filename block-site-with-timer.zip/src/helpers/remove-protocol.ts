export default (url: string): string => url.replace(/^http(s?):\/\//, "");
